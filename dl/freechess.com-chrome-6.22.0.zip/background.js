(function(a,b){if("function"==typeof define&&define.amd)define("webextension-polyfill",["module"],b);else if("undefined"!=typeof exports)b(module);else{var c={exports:{}};b(c),a.browser=c.exports}})("undefined"==typeof globalThis?"undefined"==typeof self?this:self:globalThis,function(a){"use strict";if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(!(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)){a.exports=(a=>{const b={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(0===Object.keys(b).length)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(a,b=void 0){super(b),this.createItem=a}get(a){return this.has(a)||this.set(a,this.createItem(a)),super.get(a)}}const d=a=>a&&"object"==typeof a&&"function"==typeof a.then,e=(b,c)=>(...d)=>{a.runtime.lastError?b.reject(new Error(a.runtime.lastError.message)):c.singleCallbackArg||1>=d.length&&!1!==c.singleCallbackArg?b.resolve(d[0]):b.resolve(d)},f=a=>1==a?"argument":"arguments",g=(a,b)=>function(c,...d){if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((f,g)=>{if(b.fallbackToNoCallback)try{c[a](...d,e({resolve:f,reject:g},b))}catch(e){console.warn(`${a} API method doesn't seem to support the callback parameter, `+"falling back to call it without a callback: ",e),c[a](...d),b.fallbackToNoCallback=!1,b.noCallback=!0,f()}else b.noCallback?(c[a](...d),f()):c[a](...d,e({resolve:f,reject:g},b))})},h=(a,b,c)=>new Proxy(b,{apply(b,d,e){return c.call(d,a,...e)}});let i=Function.call.bind(Object.prototype.hasOwnProperty);const j=(a,b={},c={})=>{let d=Object.create(null),e=Object.create(a);return new Proxy(e,{has(b,c){return c in a||c in d},get(e,f){if(f in d)return d[f];if(!(f in a))return;let k=a[f];if("function"==typeof k){if("function"==typeof b[f])k=h(a,a[f],b[f]);else if(i(c,f)){let b=g(f,c[f]);k=h(a,a[f],b)}else k=k.bind(a);}else if("object"==typeof k&&null!==k&&(i(b,f)||i(c,f)))k=j(k,b[f],c[f]);else if(i(c,"*"))k=j(k,b[f],c["*"]);else return Object.defineProperty(d,f,{configurable:!0,enumerable:!0,get(){return a[f]},set(b){a[f]=b}}),k;return d[f]=k,k},set(b,c,e){return c in d?d[c]=e:a[c]=e,!0},defineProperty(a,b,c){return Reflect.defineProperty(d,b,c)},deleteProperty(a,b){return Reflect.deleteProperty(d,b)}})},k=a=>({addListener(b,c,...d){b.addListener(a.get(c),...d)},hasListener(b,c){return b.hasListener(a.get(c))},removeListener(b,c){b.removeListener(a.get(c))}}),l=new c(a=>"function"==typeof a?function(b){const c=j(b,{},{getContent:{minArgs:0,maxArgs:0}});a(c)}:a),m=new c(a=>"function"==typeof a?function(b,c,e){let f,g,h=!1,i=new Promise(a=>{f=function(b){h=!0,a(b)}});try{g=a(b,c,f)}catch(a){g=Promise.reject(a)}const j=!0!==g&&d(g);if(!0!==g&&!j&&!h)return!1;const k=a=>{a.then(a=>{e(a)},a=>{let b;b=a&&(a instanceof Error||"string"==typeof a.message)?a.message:"An unexpected error occurred",e({__mozWebExtensionPolyfillReject__:!0,message:b})}).catch(a=>{console.error("Failed to send onMessage rejected reply",a)})};return j?k(g):k(i),!0}:a),n=({reject:b,resolve:c},d)=>{a.runtime.lastError?a.runtime.lastError.message==="The message port closed before a response was received."?c():b(new Error(a.runtime.lastError.message)):d&&d.__mozWebExtensionPolyfillReject__?b(new Error(d.message)):c(d)},o=(a,b,c,...d)=>{if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((a,b)=>{const e=n.bind(null,{resolve:a,reject:b});d.push(e),c.sendMessage(...d)})},p={devtools:{network:{onRequestFinished:k(l)}},runtime:{onMessage:k(m),onMessageExternal:k(m),sendMessage:o.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:o.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},q={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return b.privacy={network:{"*":q},services:{"*":q},websites:{"*":q}},j(a,p,b)})(chrome)}else a.exports=globalThis.browser});
//# sourceMappingURL=browser-polyfill.min.js.map

// webextension-polyfill v.0.12.0 (https://github.com/mozilla/webextension-polyfill)

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

;
// Firefox (MV2 background page) vs Chrome (MV3 service worker, see scripts/build-chrome.mjs).
const IS_FIREFOX = typeof browser !== "undefined" && typeof browser.runtime.getBrowserInfo === "function";

// ======================= Lichess request gate =======================
// Lichess answers "429 Too Many Requests" when a client is too busy, and then wants a full
// minute of silence. This gate spaces requests out per host, and after a 429 it stops sending
// anything to that host until the minute is over (retrying sooner only extends the block).
const _fetch = globalThis.fetch.bind(globalThis);
// gap: minimum time between requests; perMin: hard budget per minute (well under what Lichess allows).
const GATES = { "lichess.org": { gap: 1000, perMin: 20 }, "explorer.lichess.ovh": { gap: 500, perMin: 40 }, "tablebase.lichess.ovh": { gap: 300, perMin: 60 } };
for (const g of Object.values(GATES)) Object.assign(g, { until: 0, chain: Promise.resolve(), strikes: 0, sent: [] });
// Remember blocks across restarts/reinstalls of the background page, so we never hammer a blocked connection.
browser.storage.local.get("lichessBlock").then(({ lichessBlock }) => {
  for (const [h, v] of Object.entries(lichessBlock || {})) if (GATES[h] && v.until > Date.now()) Object.assign(GATES[h], v);
}).catch(() => {});
const saveBlocks = () => browser.storage.local.set({ lichessBlock: Object.fromEntries(Object.entries(GATES).map(([h, g]) => [h, { until: g.until, strikes: g.strikes }])) }).catch(() => {});
let lastLimit = null; // for the "Details" line in the UI
function rateLimited(until) {
  const secs = Math.max(1, Math.ceil((until - Date.now()) / 1000));
  return new Response(JSON.stringify({ error: "rate limited" }), { status: 429, headers: { "Retry-After": String(secs), "Content-Type": "application/json" } });
}
globalThis.fetch = async (url, opts) => {
  let host; try { host = new URL(String(url?.url || url)).host; } catch { return _fetch(url, opts); }
  const g = GATES[host];
  if (!g) return _fetch(url, opts);
  // Logging in must never be blocked by our own cool-down (it's one request, and the user asked for it).
  const isLogin = /\/api\/token\b|\/api\/account\b/.test(String(url?.url || url));
  if (Date.now() < g.until && !isLogin) return rateLimited(g.until);
  const turn = g.chain.then(async () => {
    await new Promise((r) => setTimeout(r, g.gap));
    // Hard per-minute budget: if we've already sent a lot, wait instead of sending more.
    for (;;) {
      g.sent = g.sent.filter((t) => Date.now() - t < 60000);
      if (g.sent.length < g.perMin) break;
      await new Promise((r) => setTimeout(r, 60000 - (Date.now() - g.sent[0]) + 50));
    }
    g.sent.push(Date.now());
  });
  g.chain = turn.catch(() => {});
  await turn;
  if (Date.now() < g.until && !isLogin) return rateLimited(g.until);
  const r = await _fetch(url, opts);
  if (r.status === 429) {
    // Back off harder each time Lichess keeps refusing: 1, 2, 4, 8, 15 minutes.
    g.strikes++;
    const secs = Math.max(+r.headers.get("Retry-After") || 0, Math.min(900, 61 * 2 ** (g.strikes - 1)));
    g.until = Date.now() + secs * 1000;
    saveBlocks();
    lastLimit = { url: String(url?.url || url).replace(/\?.*/, ""), at: Date.now(), secs, strikes: g.strikes, body: (await r.clone().text().catch(() => "")).slice(0, 160) };
  } else if (r.ok && g.strikes) { g.strikes = 0; saveBlocks(); }
  return r;
};
const waitSecs = (host = "lichess.org") => Math.max(0, Math.ceil((GATES[host].until - Date.now()) / 1000));
class SlowDown extends Error { constructor(host) { const s = waitSecs(host) || 60; super(`Lichess asked us to slow down for a minute. Trying again in ${s}s.`); this.retryIn = s; } }

// Background: chess.com archive → Lichess import, analysis polling, header fix for the embed, history.

async function getJson(url, opts = {}) {
  const r = await fetch(url, { ...opts, headers: { Accept: "application/json", ...(opts.headers || {}) } });
  if (r.status === 429) throw new SlowDown(new URL(url).host in GATES ? new URL(url).host : "lichess.org");
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function findPgn({ gameId, username, date }) {
  const [y, m] = date.split(/[.\-/]/).map(Number);
  const months = [[y, m], m === 12 ? [y + 1, 1] : [y, m + 1]];
  const users = [username];
  for (const u of users) for (const [yy, mm] of months) {
    let data;
    try { data = await getJson(`https://api.chess.com/pub/player/${u.toLowerCase()}/games/${yy}/${String(mm).padStart(2, "0")}`); }
    catch { continue; }
    const g = (data.games || []).find((g) => g.url?.endsWith("/" + gameId));
    if (g?.pgn) return g.pgn;
  }
  throw new Error("Couldn't find this game in chess.com's archive. Very new games can take a minute to appear, so try again shortly.");
}

async function importToLichess(pgn) {
  const r = await fetch("https://lichess.org/api/import", {
    method: "POST", body: new URLSearchParams({ pgn }), headers: { Accept: "application/json" },
  });
  if (r.status === 429) throw new SlowDown();
  if (!r.ok) throw new Error(`Lichess import failed (HTTP ${r.status})`);
  const j = await r.json();
  return j.id || j.url.split("/").pop();
}

async function getGame(id) {
  return getJson(`https://lichess.org/game/export/${id}?evals=true&accuracy=true&opening=true&clocks=true&literate=false`);
}

async function requestAnalysis(id) {
  try {
    const r = await fetch(`https://lichess.org/${id}/request-analysis`, {
      method: "POST", credentials: "include", headers: { "X-Requested-With": "XMLHttpRequest" },
    });
    // Not logged in on lichess.org: Lichess answers with a redirect to its sign-up page (still "200 OK").
    const ok = r.ok && !r.redirected && !/\/(signup|login)\b/.test(r.url);
    if (!ok) await browser.storage.local.set({ lichessNoLogin: Date.now() });
    else await browser.storage.local.remove("lichessNoLogin");
    return ok;
  } catch { return false; }
}

// Persisted cache: chess.com game id -> { id, pgn }
async function cacheGet(k) { return (await browser.storage.local.get("cache")).cache?.[k]; }
async function cacheSet(k, v) {
  const { cache = {} } = await browser.storage.local.get("cache");
  cache[k] = v;
  const keys = Object.keys(cache);
  if (keys.length > 200) delete cache[keys[0]];
  await browser.storage.local.set({ cache });
}

const handlers = {
  async import(msg) {
    const hit = await cacheGet(msg.gameId);
    if (hit) return hit;
    let pgn = msg.pgn, id;
    try { if (!pgn) throw 0; id = await importToLichess(pgn); }
    catch (e) { if (e?.message?.includes("rate")) throw e; pgn = await findPgn(msg); id = await importToLichess(pgn); }
    const v = { id, pgn };
    await cacheSet(msg.gameId, v);
    return v;
  },
  async game({ id }) { return { game: await getGame(id) }; },
  async request({ id }) {
    const ok = await requestAnalysis(id);
    if (!ok) throw new Error("login");
    return {};
  },
  async notify({ title, message }) {
    try { await browser.notifications.create({ type: "basic", iconUrl: browser.runtime.getURL("icons/icon128.png"), title, message }); } catch {}
    return {};
  },
  async openTab({ url }) { await browser.tabs.create({ url }); return {}; },
  async openOptions() { await browser.runtime.openOptionsPage(); return {}; },
  async history({ entry }) {
    const { history = [] } = await browser.storage.local.get("history");
    const h = [{ ...entry, at: Date.now() }, ...history.filter((x) => x.id !== entry.id)].slice(0, 300);
    await browser.storage.local.set({ history: h });
    return {};
  },
};

browser.runtime.onMessage.addListener(async (msg) => {
  const fn = handlers[msg.type];
  if (!fn) return;
  try { return { ok: true, ...(await fn(msg)) }; }
  catch (e) { return { ok: false, error: String(e.message || e), retryIn: e.retryIn }; }
});

// Let Lichess load in the iframe on chess.com (only for frames inside chess.com).
// Chrome does this with declarativeNetRequest rules instead (chrome/rules.json).
if (IS_FIREFOX) browser.webRequest.onHeadersReceived.addListener(
  (d) => {
    const parent = d.frameAncestors?.[0];
    const fromChessCom = (parent && /^https:\/\/www\.chess\.com\//.test(parent.url)) ||
      /^https:\/\/www\.chess\.com\//.test(d.originUrl || "");
    if (!fromChessCom) return {};
    return {
      responseHeaders: d.responseHeaders
        .filter((x) => x.name.toLowerCase() !== "x-frame-options")
        .map((x) => x.name.toLowerCase() === "content-security-policy"
          ? { name: x.name, value: x.value.split(";").filter((p) => !p.trim().startsWith("frame-ancestors")).join(";") }
          : x),
    };
  },
  { urls: ["https://lichess.org/*"], types: ["sub_frame"] },
  ["blocking", "responseHeaders"]
);

// Let chessable.com (and chess.com, where Chessable sends you to log in) load inside the hub (the add-on's own page) only: drop the headers that forbid framing,
// for frames whose parent is this add-on. Any other site framing Chessable still gets the normal headers.
const OWN = browser.runtime.getURL("");
const frameOk = (d) => (d.frameAncestors || []).some((a) => a.url?.startsWith(OWN)) || (d.originUrl || "").startsWith(OWN);
if (IS_FIREFOX) browser.webRequest.onHeadersReceived.addListener(
  (d) => frameOk(d) ? { responseHeaders: d.responseHeaders
    .filter((x) => x.name.toLowerCase() !== "x-frame-options")
    .map((x) => x.name.toLowerCase() === "content-security-policy"
      ? { name: x.name, value: x.value.split(";").filter((p) => !p.trim().startsWith("frame-ancestors")).join(";") } : x) } : {},
  { urls: ["https://www.chessable.com/*", "https://www.chess.com/*"], types: ["sub_frame"] },
  ["blocking", "responseHeaders"]
);
// Chrome: the same with a session rule limited to frames this add-on opens.
if (!IS_FIREFOX && globalThis.chrome?.declarativeNetRequest?.updateSessionRules) {
  chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [50], addRules: [{
    id: 50, priority: 1,
    action: { type: "modifyHeaders", responseHeaders: [{ header: "x-frame-options", operation: "remove" }, { header: "content-security-policy", operation: "remove" }] },
    condition: { requestDomains: ["www.chessable.com", "www.chess.com"], resourceTypes: ["sub_frame"], initiatorDomains: [chrome.runtime.id] },
  }] }).catch((e) => console.warn("chessable rule", e));
}

// Toolbar shortcut
browser.commands?.onCommand.addListener(async (cmd) => {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.startsWith("https://www.chess.com/")) {
    if (cmd === "puzzles") browser.tabs.create({ url: "https://www.chess.com/home#infinite-puzzles" });
    return;
  }
  browser.tabs.sendMessage(tab.id, { type: cmd === "puzzles" ? "puzzlesNow" : "analyseNow" });
});

// ======================= Lichess account (OAuth PKCE) =======================
const CLIENT_ID = "chesscom-free-review-ext";
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

async function getToken() { return (await browser.storage.local.get("lichessToken")).lichessToken || null; }

async function api(path, opts = {}) {
  const token = await getToken();
  const headers = { Accept: "application/json", ...(opts.headers || {}) };
  if (token) headers.Authorization = "Bearer " + token;
  const r = await fetch("https://lichess.org" + path, { ...opts, headers });
  if (r.status === 401 && token) {
    await browser.storage.local.remove(["lichessToken", "lichessUser"]);
    throw new Error("Your Lichess login expired. Please connect again.");
  }
  if (r.status === 429) throw new SlowDown();
  if (!r.ok) throw new Error(`Lichess error (HTTP ${r.status})`);
  return r.json();
}

const lcache = new Map();
Object.assign(handlers, {
  // Hub pages send their Lichess requests through here so they share the gate.
  async lget({ url, auth }) {
    const { fairLock, fairOverride = 0 } = await browser.storage.local.get(["fairLock", "fairOverride"]);
    if ((fairLock?.until || 0) > Date.now() && fairOverride < Date.now() && /explorer\.lichess|tablebase\.lichess|cloud-eval/.test(url))
      throw new Error("Locked while you're playing a game on chess.com (fair play).");
    // Positions don't change: cache explorer, tablebase and cloud-eval answers so we ask Lichess less.
    const cacheable = /explorer\.lichess|tablebase\.lichess|cloud-eval|\/api\/broadcast\/top/.test(url);
    const hit = cacheable && lcache.get(url);
    if (hit && hit.until > Date.now()) return hit.v;
    const token = auth ? await getToken() : null;
    const r = await fetch(url, { headers: { Accept: "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) } });
    if (r.status === 429) throw new SlowDown(new URL(url).host);
    let body = null; try { body = await r.json(); } catch {}
    const v = { status: r.status, body };
    if (cacheable && (r.status === 200 || r.status === 404)) {
      lcache.set(url, { v, until: Date.now() + (/broadcast/.test(url) ? 5 : 60) * 60000 });
      if (lcache.size > 400) lcache.delete(lcache.keys().next().value);
    }
    return v;
  },
  // ---- Play against Lichess's Stockfish (Board API) ----
  async aiChallenge({ level, color }) {
    const r = await fetch("https://lichess.org/api/challenge/ai", { method: "POST", headers: { Authorization: "Bearer " + (await getToken()), Accept: "application/json" },
      body: new URLSearchParams({ level: String(level), color, variant: "standard" }) });
    if (r.status === 401 || r.status === 403) throw new Error("Reconnect your Lichess account so it can start games for you.");
    if (r.status === 429) throw new SlowDown();
    if (!r.ok) throw new Error(`Lichess error ${r.status}`);
    return { game: await r.json() };
  },
  async boardMove({ id, uci }) {
    const r = await fetch(`https://lichess.org/api/board/game/${id}/move/${uci}`, { method: "POST", headers: { Authorization: "Bearer " + (await getToken()) } });
    if (!r.ok) throw new Error(`Move refused (${r.status})`);
    return {};
  },
  async boardAction({ id, action }) {
    const r = await fetch(`https://lichess.org/api/board/game/${id}/${action}`, { method: "POST", headers: { Authorization: "Bearer " + (await getToken()) } });
    return { status: r.status };
  },
  async gameState({ id }) {
    // Polled instead of streamed: one small request every ~1.5s while it's the computer's turn.
    const r = await fetch(`https://lichess.org/game/export/${id}?moves=true&tags=false&clocks=false&evals=false`, { headers: { Accept: "application/json", Authorization: "Bearer " + (await getToken()) } });
    if (r.status === 429) throw new SlowDown();
    if (!r.ok) throw new Error(`Lichess error ${r.status}`);
    return { game: await r.json() };
  },
  async ltext({ url, auth = true }) {
    const token = auth ? await getToken() : null;
    const r = await fetch(url, { headers: token ? { Authorization: "Bearer " + token } : {} });
    if (r.status === 429) throw new SlowDown();
    if (r.status === 404) throw new Error("Not found. Is the study private? Connect your Lichess account to open your own private studies.");
    if (!r.ok) throw new Error(`Lichess error ${r.status}`);
    return { text: await r.text() };
  },
  async exportStudy({ studyId, chapters }) {
    const token = await getToken(); let done = 0;
    // Lichess's import takes several chapters per request; send them in small groups.
    for (let i = 0; i < chapters.length; i += 8) {
      const group = chapters.slice(i, i + 8);
      const body = new URLSearchParams({ pgn: group.map((c) => c.pgn.replace('[Event "Mistake"]', `[Event "${c.name.replace(/"/g, "'")}"]`)).join("\n\n\n") });
      const r = await fetch(`https://lichess.org/api/study/${studyId}/import-pgn`, { method: "POST", body, headers: { Authorization: "Bearer " + token } });
      if (r.status === 429) throw new SlowDown();
      if (!r.ok) throw new Error(r.status === 403 ? "Lichess didn't allow this. Reconnect your account, or check the study belongs to you." : `Lichess error ${r.status}`);
      done += group.length;
    }
    return { done };
  },
  async limitInfo() { return { lastLimit, wait: waitSecs() }; },
  // Backup puzzle source: chess.com's public daily-puzzle archive (random puzzle).
  async ccPuzzle() {
    const r = await fetch("https://api.chess.com/pub/puzzle/random", { headers: { Accept: "application/json" } });
    if (!r.ok) throw new Error(`chess.com error ${r.status}`);
    return { puzzle: await r.json() };
  },
  async lichessLogin() {
    browser.storage.local.remove("lichessNoLogin");
    const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = b64url(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
    const state = b64url(crypto.getRandomValues(new Uint8Array(12)));
    const redirect = browser.identity.getRedirectURL();
    const url = "https://lichess.org/oauth?" + new URLSearchParams({
      response_type: "code", client_id: CLIENT_ID, redirect_uri: redirect, code_challenge_method: "S256",
      code_challenge: challenge, scope: "puzzle:read puzzle:write study:read study:write challenge:write board:play", state,
    });
    let backUrl;
    try { backUrl = await browser.identity.launchWebAuthFlow({ url, interactive: true }); }
    catch (e) { throw new Error(/cancel|closed|did not approve/i.test(String(e.message)) ? "Login cancelled." : `Lichess login window failed: ${e.message}`); }
    const back = new URL(backUrl);
    if (back.searchParams.get("state") !== state) throw new Error("Login failed (state mismatch).");
    const code = back.searchParams.get("code");
    if (!code) throw new Error(back.searchParams.get("error_description") || "Login cancelled.");
    const r = await fetch("https://lichess.org/api/token", {
      method: "POST",
      body: new URLSearchParams({ grant_type: "authorization_code", code, code_verifier: verifier, redirect_uri: redirect, client_id: CLIENT_ID }),
    });
    if (!r.ok) {
      // Show Lichess's own explanation instead of a generic message.
      let why = `HTTP ${r.status}`;
      try { const j = await r.json(); why = j.error_description || j.error || why; } catch {}
      if (r.status === 429) why = "Lichess is limiting requests from your connection right now. Wait a few minutes and try again.";
      throw new Error(`Lichess login failed: ${why}`);
    }
    const { access_token } = await r.json();
    if (!access_token) throw new Error("Lichess login failed: no token in the response.");
    for (const g of Object.values(GATES)) { g.until = 0; g.strikes = 0; } saveBlocks(); // a fresh login clears old cool-downs
    await browser.storage.local.set({ lichessToken: access_token });
    const acc = await api("/api/account");
    const user = { name: acc.username, rating: acc.perfs?.puzzle?.rating ?? null, games: acc.perfs?.puzzle?.games ?? 0 };
    await browser.storage.local.set({ lichessUser: user });
    return { user };
  },
  async lichessLogout() {
    try { await api("/api/token", { method: "DELETE" }); } catch {}
    await browser.storage.local.remove(["lichessToken", "lichessUser"]);
    return {};
  },
  async lichessUser() {
    const { lichessUser, accountCheckedAt = 0 } = await browser.storage.local.get(["lichessUser", "accountCheckedAt"]);
    if (!(await getToken())) return { user: null };
    if (Date.now() - accountCheckedAt < 10 * 60e3) return { user: lichessUser || null }; // at most every 10 minutes
    await browser.storage.local.set({ accountCheckedAt: Date.now() });
    try {
      const acc = await api("/api/account");
      const user = { name: acc.username, rating: acc.perfs?.puzzle?.rating ?? null, games: acc.perfs?.puzzle?.games ?? 0 };
      await browser.storage.local.set({ lichessUser: user });
      return { user };
    } catch { return { user: lichessUser || null }; }
  },

  // Puzzles: logged in → personalised batch + synced results. Anonymous → /api/puzzle/next.
  async puzzleBatch({ angle = "mix", difficulty = "normal" }) {
    if (await getToken()) {
      const j = await api(`/api/puzzle/batch/${angle}?nb=40&difficulty=${difficulty}`);
      return { puzzles: j.puzzles || [], glicko: j.glicko || null, synced: true };
    }
    const list = [];
    for (let i = 0; i < 3; i++) {
      try { list.push(await api(`/api/puzzle/next?angle=${angle}&difficulty=${difficulty}`)); } catch (e) { if (!list.length) throw e; break; }
    }
    return { puzzles: list, synced: false };
  },
  async puzzleSubmit({ angle = "mix", id, win, rated = true }) {
    if (!(await getToken())) return { synced: false };
    const j = await api(`/api/puzzle/batch/${angle}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ solutions: [{ id, win, rated: !!rated }] }),
    });
    const round = (j.rounds || []).find((r) => r.id === id);
    return { synced: true, glicko: j.glicko || null, ratingDiff: round?.ratingDiff ?? null, more: j.puzzles || [] };
  },
});

// ======================= Sync & backup (no Firefox Sync needed) =======================
// Your progress is stored, compressed, in a private Lichess study on your own account
// called "Free Chess Hub sync". Any PC where you connect the same Lichess account gets it.
const SYNC_KEYS_NOTE = "localCache, the Lichess token and the passphrase itself are never synced";
const SYNC_KEYS = ["puzzleStats", "puzzleSettings", "rushBest", "rushHistory", "srs", "repertoire", "history", "chesscomUser", "bulkSummary", "drillStats", "courses", "activity", "achievements", "totals", "profile"];
const STUDY_NAME = "Free Chess Hub sync";
const CHUNK = 1800;

// Sync data is gzipped, then encrypted (AES-256-GCM, key from your passphrase via PBKDF2).
// Lichess only ever stores unreadable bytes; without your passphrase nobody can read them.
async function syncKey(salt) {
  const { syncPass } = await browser.storage.local.get("syncPass");
  if (!syncPass) throw new Error("Set a sync passphrase first (Settings → Sync).");
  const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(syncPass), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 250000, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}
const toB64 = (buf) => { let s = ""; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode(...buf.subarray(i, i + 0x8000)); return btoa(s); };
async function gzipB64(obj) {
  const stream = new Blob([JSON.stringify(obj)]).stream().pipeThrough(new CompressionStream("gzip"));
  const plain = new Uint8Array(await new Response(stream).arrayBuffer());
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await syncKey(salt), plain));
  const out = new Uint8Array(1 + 16 + 12 + ct.length); out[0] = 1; out.set(salt, 1); out.set(iv, 17); out.set(ct, 29);
  return toB64(out);
}
async function unB64(b64) {
  const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  if (bin[0] !== 1) throw new Error("Unknown sync format.");
  let plain;
  try { plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bin.slice(17, 29) }, await syncKey(bin.slice(1, 17)), bin.slice(29)); }
  catch (e) { if (/passphrase/.test(e.message)) throw e; throw new Error("Wrong sync passphrase: it must be the same on every computer."); }
  const stream = new Blob([new Uint8Array(plain)]).stream().pipeThrough(new DecompressionStream("gzip"));
  return JSON.parse(await new Response(stream).text());
}

async function snapshot() {
  const data = await browser.storage.local.get(SYNC_KEYS);
  if (data.srs) data.srs = data.srs.slice(-1200);
  const settings = await browser.storage.sync.get(null);
  return { v: 1, at: Date.now(), data, settings };
}

// Merge rules: lists are unioned, counters take the larger value, the newest copy wins for the rest.
function merge(local, remote) {
  const out = { ...local };
  for (const k of SYNC_KEYS) {
    const a = local[k], b = remote[k];
    if (b == null) continue;
    if (a == null) { out[k] = b; continue; }
    if (k === "srs") {
      const m = new Map(a.map((c) => [c.fen, c]));
      for (const c of b) { const x = m.get(c.fen); if (!x || (c.reps + c.lapses) > (x.reps + x.lapses)) m.set(c.fen, c); }
      out[k] = [...m.values()];
    } else if (k === "history" || k === "rushHistory") {
      const m = new Map([...b, ...a].map((x) => [x.id || x.at, x]));
      out[k] = [...m.values()].sort((x, y) => (y.at || 0) - (x.at || 0)).slice(0, 50);
    } else if (k === "rushBest") {
      out[k] = { ...b }; for (const [m, v] of Object.entries(a)) out[k][m] = Math.max(v, b[m] ?? -1);
    } else if (k === "puzzleStats") {
      const ids = new Map([...(b.history || []), ...(a.history || [])].map((x) => [x.id + x.at, x]));
      out[k] = { ...b, ...a, solved: Math.max(a.solved || 0, b.solved || 0), failed: Math.max(a.failed || 0, b.failed || 0),
        bestStreak: Math.max(a.bestStreak || 0, b.bestStreak || 0), history: [...ids.values()].sort((x, y) => x.at - y.at).slice(-300),
        localRating: (a.history?.length || 0) >= (b.history?.length || 0) ? a.localRating : b.localRating };
    } else if (k === "repertoire") {
      out[k] = { white: { ...(b.white || {}), ...(a.white || {}) }, black: { ...(b.black || {}), ...(a.black || {}) } };
    } else if (k === "activity" || k === "totals") {
      // per day (or per counter): keep the larger number of each kind
      const maxed = (x = {}, y = {}) => { const o = { ...y }; for (const [kk, v] of Object.entries(x)) o[kk] = typeof v === "object" ? maxed(v, y[kk]) : Math.max(v, y[kk] ?? -Infinity); return o; };
      out[k] = maxed(a, b);
    } else if (k === "profile") {
      // Your choices: the newest copy wins; the rating log is joined by day.
      const newer = (a.onboarded || 0) >= (b.onboarded || 0) && (a.ratingsAt || 0) >= (b.ratingsAt || 0) ? a : b, older = newer === a ? b : a;
      const log = new Map([...(older.ratingLog || []), ...(newer.ratingLog || [])].map((x) => [new Date(x.at).toDateString(), x]));
      out[k] = { ...older, ...newer, ratingLog: [...log.values()].sort((x, y) => x.at - y.at).slice(-400) };
    } else if (k === "achievements") {
      out[k] = { ...b }; for (const [id, t] of Object.entries(a)) out[k][id] = Math.min(t, b[id] ?? Infinity);
    } else if (k === "courses") {
      const prog = { ...(b.progress || {}) };
      for (const [cid, lines] of Object.entries(a.progress || {})) prog[cid] = { ...(prog[cid] || {}), ...lines };
      out[k] = { custom: { ...(b.custom || {}), ...(a.custom || {}) }, progress: prog };
    } else out[k] = a;
  }
  return out;
}

async function lichessUserName() { return (await browser.storage.local.get("lichessUser")).lichessUser?.name; }
async function findSyncStudy() {
  const u = await lichessUserName(); if (!u) throw new Error("Connect your Lichess account first.");
  const token = await getToken();
  const r = await fetch(`https://lichess.org/api/study/by/${encodeURIComponent(u)}`, { headers: { Authorization: "Bearer " + token, Accept: "application/x-ndjson" } });
  if (r.status === 401 || r.status === 403) throw new Error("Please reconnect your Lichess account so sync can use your studies.");
  if (!r.ok) throw new Error(`Lichess error ${r.status}`);
  const lines = (await r.text()).split("\n").filter(Boolean).map((l) => JSON.parse(l));
  return lines.find((s) => s.name?.trim().toLowerCase() === STUDY_NAME.toLowerCase())?.id || null;
}
async function readRemote(studyId) {
  const pgn = await (await fetch(`https://lichess.org/api/study/${studyId}.pgn?comments=true&clocks=false`, { headers: { Authorization: "Bearer " + (await getToken()) } })).text();
  const chapters = pgn.split(/\n\n(?=\[Event )/);
  const parts = {}, ids = [];
  for (const ch of chapters) {
    const name = ch.match(/\[ChapterName "([^"]*)"\]/)?.[1] || ch.match(/\[Event "[^"]*?:\s*([^"]*)"\]/)?.[1] || "";
    const url = ch.match(/\[ChapterURL "[^"]*\/([A-Za-z0-9]{8})"\]/)?.[1];
    const m = name.match(/^FCH (\d+) (\d+)\/(\d+)$/);
    if (!m) continue;
    ids.push({ stamp: +m[1], id: url });
    const data = ch.match(/\{\s*([A-Za-z0-9+/=]+)\s*\}/)?.[1];
    (parts[m[1]] ||= { n: +m[3], chunks: {} }).chunks[+m[2]] = data;
  }
  const stamps = Object.keys(parts).map(Number).sort((a, b) => b - a);
  for (const st of stamps) {
    const p = parts[st];
    if (Object.keys(p.chunks).length === p.n && Object.values(p.chunks).every(Boolean)) {
      return { snap: await unB64(Array.from({ length: p.n }, (_, i) => p.chunks[i + 1]).join("")), chapters: ids };
    }
  }
  return { snap: null, chapters: ids };
}
async function writeRemote(studyId, snap, oldChapters) {
  const b64 = await gzipB64(snap);
  const n = Math.ceil(b64.length / CHUNK);
  if (n > 60) throw new Error("Too much data to sync. Try clearing old Mistake Trainer positions.");
  const stamp = Date.now();
  const token = await getToken();
  for (let i = 0; i < n; i++) {
    const body = new URLSearchParams({ name: `FCH ${stamp} ${i + 1}/${n}`, pgn: `[Event "FCH"]\n\n{ ${b64.slice(i * CHUNK, (i + 1) * CHUNK)} } *` });
    const r = await fetch(`https://lichess.org/api/study/${studyId}/import-pgn`, { method: "POST", body, headers: { Authorization: "Bearer " + token } });
    if (!r.ok) throw new Error(`Couldn't save to Lichess (HTTP ${r.status}).`);
  }
  for (const c of oldChapters) if (c.id) await fetch(`https://lichess.org/api/study/${studyId}/${c.id}`, { method: "DELETE", headers: { Authorization: "Bearer " + token } }).catch(() => {});
}

let syncing = false, quietUntil = 0, lastPushed = "";
async function digest(o) { return toB64(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(o))))); }
async function syncNow() {
  if (syncing) return { busy: true };
  if (waitSecs() > 0) throw new SlowDown();
  syncing = true;
  try {
    const studyId = await findSyncStudy();
    if (!studyId) return { needStudy: true };
    const { snap: remote, chapters } = await readRemote(studyId);
    const local = await browser.storage.local.get(SYNC_KEYS);
    if (remote) {
      const merged = merge(local, remote.data || {});
      quietUntil = Date.now() + 5000;
      await browser.storage.local.set(merged);
      const { syncAt = 0 } = await browser.storage.local.get("syncAt");
      if (remote.settings && remote.at > syncAt) await browser.storage.sync.set(remote.settings);
    }
    // Only upload when something actually changed since the last upload.
    const snap = await snapshot();
    const h = await digest(snap.data);
    if (h !== lastPushed || !remote) { await writeRemote(studyId, snap, chapters); lastPushed = h; }
    quietUntil = Date.now() + 5000; // our own writes below must not trigger another sync
    await browser.storage.local.set({ syncAt: Date.now(), syncError: null });
    return { ok2: true, at: Date.now() };
  } catch (e) {
    await browser.storage.local.set({ syncError: String(e.message || e) });
    throw e;
  } finally { syncing = false; }
}

Object.assign(handlers, {
  async syncNow() { return await syncNow(); },
  async syncStatus() {
    const { syncAt, syncError, syncEnabled } = await browser.storage.local.get(["syncAt", "syncError", "syncEnabled"]);
    return { syncAt, syncError, syncEnabled: !!syncEnabled, user: await lichessUserName() };
  },
  async backup() { return { snap: await snapshot() }; },
  async restore({ snap }) {
    if (!snap?.data) throw new Error("That file isn't a freeChess.com backup.");
    const local = await browser.storage.local.get(SYNC_KEYS);
    await browser.storage.local.set(merge(local, snap.data));
    if (snap.settings) await browser.storage.sync.set(snap.settings);
    return {};
  },
});

// Automatic sync: on start, every 15 minutes, and shortly after progress changes.
let syncTimer = null;
const autoSync = async () => { const { syncEnabled } = await browser.storage.local.get("syncEnabled"); if (syncEnabled) syncNow().catch(() => {}); };
browser.storage.onChanged.addListener((ch, area) => {
  if (syncing || Date.now() < quietUntil) return;
  if (area === "local" && SYNC_KEYS.some((k) => k in ch)) { clearTimeout(syncTimer); syncTimer = setTimeout(autoSync, 120000); }
});
setTimeout(autoSync, 8000);
setInterval(autoSync, 15 * 60e3);

// First install: open the setup. (Updates don't re-open it.)
browser.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") browser.tabs.create({ url: browser.runtime.getURL("welcome.html") });
});

// ======================= Daily reminder & achievement notifications =======================
const notifyNow = (title, message) => browser.notifications.create({ type: "basic", iconUrl: browser.runtime.getURL("icons/icon128.png"), title, message }).catch(() => {});
async function scheduleReminder() {
  const { reminder = "off" } = await browser.storage.sync.get("reminder");
  await browser.alarms.clear("fc-reminder");
  if (!/^\d\d:\d\d$/.test(reminder)) return;
  const [hh, mm] = reminder.split(":").map(Number), t = new Date(); t.setHours(hh, mm, 0, 0);
  if (t <= new Date()) t.setDate(t.getDate() + 1);
  browser.alarms.create("fc-reminder", { when: t.getTime(), periodInMinutes: 1440 });
}
browser.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== "fc-reminder") return;
  const d = new Date(), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const { activity = {} } = await browser.storage.local.get("activity");
  const s = await browser.storage.sync.get(["goalPuzzles", "goalCourse"]);
  const day = activity[key] || {}, pz = +s.goalPuzzles || 10, cs = +s.goalCourse || 5;
  if ((day.puzzle || 0) >= pz && (day.course || 0) >= cs) return; // goal already done today
  notifyNow("Time to train ♞", `Today: ${day.puzzle || 0}/${pz} puzzles, ${day.course || 0}/${cs} course moves. Keep your streak going!`);
});
browser.storage.onChanged.addListener((ch, area) => { if (area === "sync" && ch.reminder) scheduleReminder(); });
scheduleReminder();
// ======================= Update notifier (major releases only) =======================
// Chrome builds can't update themselves when installed from the download page, so they're told about new
// major versions. Firefox updates itself; it just says what's new after a major update.
const RELEASES = "https://codesieb.github.io/freechess-releases";
const vparts = (v) => String(v).split(".").map((n) => +n || 0);
const newer = (a, b) => { const x = vparts(a), y = vparts(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
async function checkUpdate(force = false) {
  const { updateLastCheck = 0 } = await browser.storage.local.get("updateLastCheck");
  if (!force && Date.now() - updateLastCheck < 11 * 3600e3) return;
  await browser.storage.local.set({ updateLastCheck: Date.now() });
  let latest; try { const r = await fetch(`${RELEASES}/latest.json?t=${Date.now()}`, { cache: "no-store" }); if (!r.ok) return; latest = await r.json(); } catch { return; }
  const mine = browser.runtime.getManifest().version;
  if (!latest?.version || !newer(latest.version, mine)) { await browser.storage.local.remove("updateAvail"); return; }
  const major = latest.major || vparts(latest.version)[0] > vparts(mine)[0];
  if (!major || IS_FIREFOX) return;
  const { updateAvail, updateNotified } = await browser.storage.local.get(["updateAvail", "updateNotified"]);
  if (updateAvail?.version !== latest.version) await browser.storage.local.set({ updateAvail: latest });
  if (updateNotified !== latest.version) {
    await browser.storage.local.set({ updateNotified: latest.version });
    browser.notifications.create("fc-update", { type: "basic", iconUrl: browser.runtime.getURL("icons/icon128.png"), title: `freeChess.com ${latest.version} is out`, message: (latest.notes || []).slice(0, 2).join(" · ") || "Click to download the new version." }).catch(() => {});
  }
}
browser.notifications.onClicked?.addListener((id) => { if (id === "fc-update" || id === "fc-whatsnew") browser.tabs.create({ url: `${RELEASES}/` }); });
browser.alarms.create("fc-update", { periodInMinutes: 720, delayInMinutes: 1 });
browser.alarms.onAlarm.addListener((a) => { if (a.name === "fc-update") checkUpdate(); });
browser.runtime.onInstalled.addListener(async ({ reason, previousVersion }) => {
  if (reason !== "update") return;
  await browser.storage.local.remove("updateAvail");
  try {
    const latest = await (await fetch(`${RELEASES}/latest.json?t=${Date.now()}`, { cache: "no-store" })).json();
    const mine = browser.runtime.getManifest().version;
    if (latest.version === mine && (latest.major || vparts(mine)[0] > vparts(previousVersion)[0]) && latest.notes?.length)
      await browser.storage.local.set({ whatsNew: { version: mine, notes: latest.notes } });
  } catch {}
});
Object.assign(handlers, {
  // The sharing server (Netlify): only https URLs ending in /api/…, JSON in and out.
  async srv({ url, body }) {
    const u = new URL(url);
    if (u.protocol !== "https:" && u.hostname !== "localhost") throw new Error("The sharing server must use https.");
    if (!u.pathname.startsWith("/api/")) throw new Error("Bad server path.");
    const r = await fetch(u.href, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `Server error ${r.status}`);
    return { data };
  },
  async reloadSelf() { setTimeout(() => browser.runtime.reload(), 100); return {}; },
  async checkUpdate() { await checkUpdate(true); return (await browser.storage.local.get("updateAvail")).updateAvail || null; },
  async achievement({ names }) { notifyNow("Achievement unlocked", names.join(", ")); return {}; },
});

;
// Chrome service worker part: private analysis is forwarded to the offscreen page (see src/offscreen.js).
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  try { await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["WORKERS"], justification: "Run the Stockfish chess engine for private game analysis." }); }
  catch (e) { if (!/single offscreen/i.test(String(e.message))) throw e; }
}
// Right after the offscreen page is created its script may not be listening yet ("Receiving end does
// not exist"), so try again for a few seconds.
const offCall = async (m) => {
  for (let i = 0; ; i++) {
    await ensureOffscreen();
    try { return await chrome.runtime.sendMessage(m); }
    catch (e) { if (i >= 25 || !/Receiving end|establish connection/i.test(String(e.message))) throw e; await new Promise((r) => setTimeout(r, 200)); }
  }
};
Object.assign(handlers, {
  async analyseLocal({ key, pgn, ms = 250 }) {
    const { localCache = {} } = await browser.storage.local.get("localCache");
    if (localCache[key]) return { game: localCache[key] };
    const r = await offCall({ type: "off:analyse", key, pgn, ms: +ms });
    if (!r?.ok) throw new Error(r?.error || "Analysis failed");
    localCache[key] = r.game;
    const keys = Object.keys(localCache); if (keys.length > 30) delete localCache[keys[0]];
    await browser.storage.local.set({ localCache });
    return { game: r.game };
  },
  async bestMove({ fen, ms = 800 }) { const r = await offCall({ type: "off:best", fen, ms }); if (!r?.ok) throw new Error(r?.error || "Engine failed"); return { best: r.best }; },
  async bestLine({ fen, ms = 1200 }) { const r = await offCall({ type: "off:line", fen, ms }); if (!r?.ok) throw new Error(r?.error || "Engine failed"); return { line: r.line }; },
  async localProgress({ key }) { const r = await offCall({ type: "off:progress", key }).catch(() => null); return { pct: r?.pct ?? null }; },
  async pgn(msg) { return { pgn: await findPgn(msg) }; },
});
